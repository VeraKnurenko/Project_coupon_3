package com.jb.Project_coupon_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCoupon3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
