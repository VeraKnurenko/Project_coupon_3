package com.jb.Project_coupon_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectCoupon3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectCoupon3Application.class, args);
	}

}
