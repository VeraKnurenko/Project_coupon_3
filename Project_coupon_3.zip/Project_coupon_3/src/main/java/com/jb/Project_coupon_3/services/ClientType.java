package com.jb.Project_coupon_3.services;

public enum ClientType {
    ADMIN, COMPANY, CUSTOMER;

}
