package com.jb.Project_coupon_3.models;

public enum Category {
    FOOD, ELECTRICITY, RESTAURANT, VACATION

}
